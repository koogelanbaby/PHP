<!DOCTYPE html>
<html lan="en" and dir="Itr">

<head>
    <meta charset="utf-8">
    <title> PEER SYSTEM</title>
   <link rel="stylesheet" href="logstyle.css">
    <!--><script src="login.js"></script><!-->
</head>

<body>
    <div class="square">
    <form  action="loginsettings.php" method="POST"> 
    <h1>
        login
    </h1>
<input type="text" name="StudentID" class="form-control" placeholder="Enter StudentID" id="StudentID" required>
<input type="password" name="Password" placeholder="Enter Password" id="Password" required>
<input type="submit" name="" value="Login" onclick="correct()">
 <br><br>
 Don"t have a account?<a href="Register.php">&nbsp;Sign Up</a>   
    </form>
    </div>
    </body>
    
</html> 